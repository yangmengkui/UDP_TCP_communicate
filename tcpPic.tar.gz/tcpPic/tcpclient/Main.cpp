#include "ImageStream.h"
#include <QApplication>

int main(int argc,char *argv[])
{
   QApplication a(argc,argv);
   ImageStream qq;
   return a.exec();
}
