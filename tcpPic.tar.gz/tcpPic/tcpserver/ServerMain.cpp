#include "ServerStream.h"
//#include <QtGui/QApplication>
#include <QApplication>

int main(int argc,char *argv[])
{
   QApplication a(argc,argv);
   ServerStream *stream = new ServerStream;
   stream->show();
   return a.exec();
}
