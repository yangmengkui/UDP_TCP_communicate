#ifndef IMAGESTREAM_H_
#define IMAGESTREAM_H_
#define PIC_WIDTH 800
#define PIC_HEIGHT 800

#include <QWidget>
#include <QLabel>
#include <iostream>
#include <QtGui/QPalette>
#include <QtNetwork/QHostAddress>
#include <QtNetwork/QTcpSocket>
#include <QtNetwork/QTcpServer>




class ServerStream : public QWidget{
   Q_OBJECT
   private:
      QTcpServer server;
      QTcpSocket *socket;   //socket对象
      QLabel *ql_show;
      QByteArray imageData;   //存放接收到的图片数据的QByteArray
//      QTimer *timerConnect;
      bool hasReadHead;   //是否接收到了当前所接收图片的第一个数据包。
      long avalibleNum;
      void initNetWork();
   public:
      ServerStream(QWidget *qw=0);
      ~ServerStream();
      void changeFace();
      bool flag;
signals:
//      void serverDis();
 public slots:
      void getSocketImage();  //获取从服务器端传来的图片数据
      void conEstablished();//建立连接
       void dealConnection();
//       void disConnected();
//      void serverDisCon();//服务器断开连接

};

#endif
