#include "ServerStream.h"
#include <QTcpSocket>
#include <QtCore/QFile>
#include <QtCore/QByteArray>
#include <QTimer>

ServerStream::ServerStream(QWidget *qw) : QWidget(qw)
{
    initNetWork();
    this->setGeometry(0,0,1000,1000);
    ql_show = new QLabel(this);
    ql_show->setGeometry(50,50,PIC_WIDTH,PIC_HEIGHT);
    ql_show->setAutoFillBackground(true);
    hasReadHead = false;
    avalibleNum = 0;
}


ServerStream::~ServerStream(){

}

void ServerStream::changeFace()
{
    QPalette palette;
    QImage copy;
    QImage image = QImage::fromData(imageData,"jpg");
    //    QImage image=QImage::fromData(imageData);
    /*把数据转换成图片.默认方式下，程序会尝试判断图片的格式.*/
    //if(image.width()>=image.height())
    //{
    //   copy = image.scaledToWidth(PIC_WIDTH);
    //}
    //else{
    //    copy = image.scaledToHeight(PIC_HEIGHT);
    //}
    copy = image.scaled(800,800);
    palette.setBrush(QPalette::Background, QBrush(copy));
    ql_show->setPalette(palette);
}

void ServerStream::getSocketImage()
{
    if(!hasReadHead){
        imageData.clear();   //第一个数据包发来时，先清空存储图片数据的空间
        QByteArray data = socket->readAll();//
        bool ok;
        avalibleNum = data.left(8).toInt(&ok,16);   //找出第一个数据包的前8个字节,由此获得数据总长度。
        std::cout << "avalibleNum=" << avalibleNum << std::endl;
        data.remove(0,8);  //移除前8个字节
        imageData.append(data);
        hasReadHead = true;
        if(imageData.length() >= avalibleNum){   //判断数据是否接收完毕
            std::cout << "receive a image,length=" << avalibleNum << std::endl << std::endl;
            changeFace();
            hasReadHead = false;
        }
    }
    else{
        QByteArray data = socket->readAll();
        imageData.append(data);
        if(imageData.length() >= avalibleNum){   //判断数据是否接收完毕
            std::cout << "receive a image,length=" << avalibleNum << std::endl << std::endl;
            changeFace();
            hasReadHead = false;
        }
    }
}

void ServerStream::dealConnection()
{
    socket = server.nextPendingConnection();
    connect(socket,SIGNAL(readyRead()),this,SLOT(getSocketImage()));
    std::cout << "in dealConnection11111111111111111111" << std::endl << std::endl;
}

void ServerStream::conEstablished()
{
    //    flag = true;
    std::cout << "connect established!" << std::endl;
}

//void ServerStream::disConnected()
//{
//    std::cout<<"6666666666666666666666"<<std::endl;
//    socket->close();
//    flag = false;
//    timerConnect->start(100);
//}


//初始化网络
void ServerStream::initNetWork(){
    std::cout << "initing network" << std::endl;
    socket = new QTcpSocket;
    server.setParent(this);
    server.listen(QHostAddress::Any,3333);
    connect(socket,SIGNAL(connected()),this,SLOT(conEstablished()));
    connect(&server,SIGNAL(newConnection()),this,SLOT(dealConnection()));
    std::cout << "network inited!" << std::endl;
    socket->setReadBufferSize(1024*1024);//设置接收端缓冲区大小
}




